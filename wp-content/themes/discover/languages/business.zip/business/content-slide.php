<?php global $previews; ?>

<div class='slide' src='<?php if ($thumb=wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID), 'slide-preview')) echo $thumb[0]; ?>'>

<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'lizard' ) ); ?>
			
</div>
