<?php


if ( !is_super_admin() ) return;
 

add_editor_style( 'styles/editor.css' );
add_editor_style( 'styles/shortcodes.css' );
add_filter( 'tiny_mce_version', 'my_refresh_mce');
add_filter('tiny_mce_before_init', 'myformatTinyMCE' );

if ( get_current_post_type()=='slides' ) {
	add_editor_style( 'styles/editor-slides.css' );
}


add_action('save_post', 'lz_feedback_options_update', 0);

add_action('save_post', 'lz_slides_params_update', 0);

add_action('admin_init', 'lz_records_params', 1);
add_action('admin_init', 'lz_feedback_options', 1);
add_action('init', 'add_mcepanel');
add_action('admin_head', 'lz_head');
add_action('admin_menu', 'themeMenu');

if (isset($_GET['page'])&&isset($_GET['action'])&&$_GET['action']=='reset') {
	include_once ( get_template_directory().'/inc/default.php' );
	$result=$lz_default[$_GET['page']];
	update_option( $_GET['page'], $result );
	wp_redirect('?page='.$_GET['page']);
}

function get_current_post_type() {
	global $post, $typenow, $current_screen;

	if ( $post && $post->post_type )
		return $post->post_type;
	elseif( $typenow )
		return $typenow;
	elseif( $current_screen && $current_screen->post_type )
		return $current_screen->post_type;
	elseif( isset( $_REQUEST['post_type'] ) )
		return sanitize_key( $_REQUEST['post_type'] );
	elseif( isset( $_GET['action'] ) && $_GET['action']=='edit' )
		return get_post_type( $_GET['post'] );
	return null;
	
}

function myformatTinyMCE($in) {
	$in['object_resizing']=false;
	return $in;
}
function my_refresh_mce($ver) {
	$ver += 3;
	return $ver;
} 


	
	function lz_head() { ?>
		<link rel='stylesheet' href='<?php echo get_template_directory_uri()?>/styles/dashboard.css' type='text/css' media='all' />
		<script>
			var admin_mail='<?php echo get_option('admin_email'); ?>';
		</script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri()?>/js/dashboard.js"></script>
		<?php if (isset($_GET['page'])&&$_GET['page']!=''&&basename($_SERVER['SCRIPT_FILENAME'])=='admin.php') { ?>
			<link rel='stylesheet' href='<?php echo get_template_directory_uri()?>/styles/admin.css' type='text/css' media='all' />
			<script type="text/javascript" src="<?php echo get_template_directory_uri()?>/js/ajaxupload.js"></script>
		<script>
			jQuery('.lz-reset').live('click', function() {
				if (! confirm(jQuery(this).text()+' to defaults?')) return false;
			});
			jQuery('.lz-item').live('click', function() {
				jQuery('.lz-panel').hide();
				jQuery('.lz-menu ul').show();
				jQuery('.lz-title').html(jQuery(this).text());
				if( jQuery('.lz-menu-item.active').attr('alt')[0]!='_' ) {
					jQuery('.lz-reset').attr('href', '?page='+jQuery(this).attr('alt')+'&action=reset');
					jQuery('.lz-reset').html('Reset '+jQuery(this).text()+' settings');
					jQuery('.lz-savesettings').show();
					jQuery('.lz-reset').show();
				}
				jQuery('.lz-page.lz-'+jQuery(this).attr('alt')).show().addClass('active').siblings('.lz-page').hide().removeClass('active');
				jQuery('#lz-settings').css('padding-top',jQuery('.lz-menu').height()+'px');
				return false;
			});
			jQuery('.lz-support').live('click', function() {
				jQuery('.lz-panel').hide();
				jQuery('.lz-menu ul').show();
				jQuery('.lz-title').html(jQuery(this).text());
				
				jQuery('.lz-page.lz-support-page').show().addClass('active').siblings('.lz-page').hide().removeClass('active');
				jQuery('#lz-settings').css('padding-top',jQuery('.lz-menu').height()+'px');
				return false;
			});
			jQuery('.lz-menu-item').live('click', function() {
				jQuery('.lz-menu-item').removeClass('active');
				jQuery(this).addClass('active');
				jQuery(this).find('img').attr('src');
				jQuery('.lz-title').html(jQuery(this).text());
				if( jQuery('.lz-menu-item.active').attr('alt')[0]!='_' ) {
					jQuery('.lz-reset').html('Reset '+jQuery(this).text()+' settings');
					jQuery('.lz-reset').attr('href', '?page='+jQuery(this).attr('alt')+'&action=reset');
					jQuery('.lz-savesettings').show();
					jQuery('.lz-reset').show();
				} else {
					jQuery('.lz-savesettings').hide();
					jQuery('.lz-reset').hide();
				}
				jQuery('.lz-page.lz-'+jQuery(this).attr('alt')).show().addClass('active').siblings('.lz-page').hide().removeClass('active');
				jQuery('#lz-settings').css('padding-top',jQuery('.lz-menu').height()+'px');
				
				jQuery('#toplevel_page_LZSettings ul li').eq(jQuery(this).parent().index()+2).addClass('current').siblings().removeClass('current');
				return false;
			});
			jQuery('.lz-savesettings').live('click', function() {
				var data=jQuery('.lz-page.active .lz-form').serialize();
				jQuery('.lz-savesettings').hide();
				jQuery('.lz-reset').hide();
				jQuery('.lz-progress').show();
				jQuery.post('<?php echo admin_url( 'admin-ajax.php' ); ?>', {
						'action':'save_settings',
						'section':jQuery('.lz-page.active').attr('alt'),
						'data':data
					}, 
					function(response){ 
						jQuery('.lz-status').text(response).show();
						jQuery('.lz-progress').hide();
						setTimeout("jQuery('.lz-status').hide()", 2000);
						setTimeout("jQuery('.lz-status').text('');", 2000);
						setTimeout("jQuery('.lz-savesettings').show()", 2000);
						setTimeout("jQuery('.lz-reset').show();", 2000);
					}
				);
			});
			jQuery('.installdemo').live('click', function() {
				
				jQuery('.lz-progress').show();
				jQuery.post('<?php echo admin_url( 'admin-ajax.php' ); ?>', {
						'action':'install_demo'
					}, 
					function(response){ 
						jQuery('.lz-status').text(response).show();
						jQuery('.lz-progress').hide();
						setTimeout("jQuery('.lz-status').hide()", 2000);
						setTimeout("jQuery('.lz-status').text('');", 2000);
					}
				);
			});
			jQuery(document).ready(function() {
				jQuery('.menu-hover').css({
					left:jQuery('.lz-menu-item.active').position().left,
					width:jQuery('.lz-menu-item.active').innerWidth(),
					display:'block'
				});
				jQuery('#lz-settings').css('padding-top',jQuery('.lz-menu').height()+'px');
				jQuery('.lz-imageupload').each(function(){
					var button=jQuery(this);
					new AjaxUpload( button, {
						action: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
						data: {
							action : 'upload_image'
						},
						name: 'uploadfile',
						onComplete: function(file, response){
							jQuery(button).prev('input').val(response);
							jQuery(button).parent().find('.img img').attr('src', response);
						}
					});
				});
				if( jQuery('.lz-menu-item.active').attr('alt')[0]!='_' ) {
					jQuery('.lz-savesettings').show();
					jQuery('.lz-reset').show();
				}
			});
			jQuery('.lz-select img').live('click', function() {
				jQuery(this).parent().find('input').val(jQuery(this).attr('alt'));
				jQuery(this).addClass('active').siblings().removeClass('active');
			});
			jQuery('.lz-menu li a').live('mouseover', function() {
				jQuery('.menu-hover').stop().animate({
					left:jQuery(this).position().left,
					width:jQuery(this).innerWidth()
				}, 500, function(){});
			});
			jQuery('.lz-menu-container').live('mouseleave', function() {
				jQuery('.menu-hover').stop().animate({
					left:jQuery('.lz-menu-item.active').position().left,
					width:jQuery('.lz-menu-item.active').innerWidth()
				}, 500, function(){});
			});
		</script>
		<?php if ( $_GET['page']!='LZSettings' ) { ?>
		<style>
			.lz-panel {display:none;}
			.lz-menu ul {display:block;}
			.lz-page.lz-<?php echo $_GET['page']; ?> {display:block;}
		</style>
		<?php } ?>
		<?php } ?>
	<?php }
	
	



function add_mcepanel() {
   if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
     return;
   if ( get_user_option('rich_editing') == 'true') {
     add_filter('mce_external_plugins', 'add_mceplugin');
     add_filter('mce_buttons_3', 'register_mcepanel');
   }
}

function register_mcepanel($buttons) {
	global $typenow;
	switch ( $typenow ) {
		case 'slides':
			array_push( $buttons, 'addElement', 'removeElement', 'getHelp' );
			break;
		default:
			array_push( $buttons, 'insetYouTube', 'insertVimeo', 'insertSound', 'columns', 'buttons', 'tooltips', 'maps', 'highlights' );
	}
	return $buttons;
}

function add_mceplugin($plugin_array) {
	global $typenow;
	switch ( $typenow ) {
		case 'slides':
			$plugin_array['slidespanel'] = get_template_directory_uri() .'/js/editor_plugin_slides.js';
			break;
		default:
			$plugin_array['postspanel'] = get_template_directory_uri() .'/js/editor_plugin_posts.js';
	}
	return $plugin_array;
}

function lz_records_params() {
	$post_types=get_post_types(array());
	foreach( $post_types as $type ) {
		if ($type=='slides') {
			add_meta_box( 'sliderBgr', 'Slide options', 'sliderbgr_func', 'slides', 'side', 'high'  );  
			add_meta_box( 'sliderCSS', 'Element options', 'slidecss_func', 'slides', 'side', 'high'  );  
		}
	}
}
function sliderbgr_func($post) {
	global $APage;
		$bgr = get_post_meta($post->ID, 'background', true);
		$bgr = wp_parse_args( (array) $bgr, array('image'=>'', 'color'=>'' ));
	?>
	<link rel="stylesheet" media="screen" type="text/css" href="<?php echo get_template_directory_uri(); ?>/styles/colorpicker.css" />
	<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/colorpicker.js"></script>
	<input type='hidden' id='bgrClr' name='background[image]' value='<?php echo $bgr['image']; ?>' />
	<span class='button slidebgrclr'>Background Color</span>
	<input type='hidden' name='background[color]' value='<?php echo $bgr['color']; ?>' />
	<script>
		jQuery(document).ready(function() {
			jQuery('#post-preview').hide();
		});	
		jQuery('.slidebgrclr').ColorPicker({
			color: '<?php echo $bgr['color']; ?>',
			onChange: function (hsb, hex, rgb) {
				var bgr=jQuery(tinymce.activeEditor.getBody()).find('.bgrClr');
				bgr.css('background-color', "#"+hex);
				bgr.attr('data-mce-style', bgr.attr('style'));
				jQuery('#bgrClr').val("#"+hex);
			},
			onBeforeShow: function(){
				if( jQuery(tinymce.activeEditor.getBody()).find('.bgrClr').length==0 )
					tinymce.execCommand('mceInsertContent', false, '<div class=\'bgrClr\'></div>');
			}
		});
		
	</script><div class="clear" style="margin-bottom:20px"></div>
	<a href="http://lizardthemes.com/documentation/slider/" target="_blank">How to create slides?</a>
	<?php
}

function slidecss_func($post) { ?>
	<div class='csseditor css-background'>
		<span class='label hide'>Hide</span>
		<p>Color</p>
		<div class='csscolor'></div>
		<label for="bgr-color">Transparent:</label> <input type='checkbox' class='csscolor-value' id="bgr-color" name='bgr-color' value='transparent' />
		<p>Image</p>
		<input type="text" name="bgr-img" value="" style="width:287px" /><span class="button">Upload</span>
		<p>Position</p>
		<input type="text" name="bgr-pos" value="" style="width:100%" />
		<p>Repeat</p>
		<select name='bgr-repeat' style="width:100%">
			<option value='no-repeat'>No repeat</option>
			<option value='repeat'>Tile</option>
			<option value='repeat-x'>Tile Horizontally</option>
			<option value='repeat-y'>Tile Vertically</option>
		</select>
		<p></p>
		<script>
			jQuery('#bgr-color').live('change', function() {
				if ( jQuery(this).prop('checked') ) 
					jQuery(this).val('transparent');
				else 
					jQuery(this).val("#"+jQuery(this).parents('.csseditor').find('.colorpicker_hex input').val());
			});
			jQuery('.css-background input').live('change', function() {
				var background='';
				if (jQuery('input[name="bgr-img"]').val()!='') {
					background+="url("+jQuery('input[name="bgr-img"]').val()+") ";
				}
				background+=jQuery('input[name="bgr-pos"]').val()+" ";
				background+=jQuery('select[name="bgr-repeat"]').val()+" ";
				background+=jQuery('input[name="bgr-color"]').val()+" ";
				jQuery('.csss input[name="background"]').val(background).change();
			});
			jQuery('.css-background select').live('change', function() {
				jQuery('.css-background input').change();
			});
		</script>
	</div>
	<div class='csseditor css-border'>
		<span class='label hide'>Hide</span>
		<p>Border color</p>
		<div class='csscolor'></div>
		<input type='hidden' class='csscolor-value' name='border-color' value='none' />
		<p>Border width</p>
		<input type="text" name="border-width" value="" style="width:100%" />
		<p>Border style</p>
		<select name='border-style' style="width:100%">
			<option value='solid'>Solid</option>
			<option value='dotted'>Dotted</option>
			<option value='dashed'>Dashed</option>
			<option value='double'>Double</option>
			<option value='groove'>Groove</option>
			<option value='ridge'>Ridge</option>
			<option value='inset'>Inset</option>
			<option value='outset'>Outset</option>
		</select>
		<p></p>
		<script>
			jQuery('.css-border input').live('change', function() {
				var border='';
				border+=jQuery('input[name="border-width"]').val()+" ";
				border+=jQuery('select[name="border-style"]').val()+" ";
				border+=jQuery('input[name="border-color"]').val();
				jQuery('.csss input[name="border"]').val(border).change();
			});
			jQuery('.css-border select').live('change', function() {
				jQuery('.css-border input').change();
			});
		</script>
	</div>
	<div class='csseditor css-padding'>
		<span class='label hide'>Hide</span>
		<p>Padding</p>
		<div class='padding-option'>
			<input type='text' name='pdtop' value='0' >
			<input type='text' name='pdbottom' value='0' >
			<input type='text' name='pdleft' value='0' >
			<input type='text' name='pdright' value='0' >
		</div>
		<script>
			jQuery('.css-padding input').live('change', function() {
				var padding='';
				padding+=jQuery('input[name="pdtop"]').val()+"px ";
				padding+=jQuery('input[name="pdright"]').val()+"px ";
				padding+=jQuery('input[name="pdbottom"]').val()+"px ";
				padding+=jQuery('input[name="pdleft"]').val()+"px";
				jQuery('.csss input[name="padding"]').val(padding).change();
			});
		</script>
	</div>
	<div class='csss'>
		<p class='description'>Click twice on needed element to see its CSS</p>
	</div>
	<script>
		var hexDigits = new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"); 
		function rgb2hex(rgb) {
			if (rgb=='transparent') return "#ffffff";
			if (rgb=='') return "none";
			rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
			return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
		}
		function hex(x) {
			return isNaN(x) ? "00" : hexDigits[(x - x % 16) / 16] + hexDigits[x % 16];
		}
		jQuery('#sliderCSS .csss input').live('change', function() {
			jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').css( jQuery(this).attr('name') , jQuery(this).attr('value') );
			jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').attr('data-mce-style', jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').attr('style'));
		});
		jQuery('.customizecss').live('click', function() {
			jQuery(".css-"+jQuery(this).prev('input').attr('name')).show();
			switch( jQuery(this).prev('input').attr('name') ) {
				case 'border':
					var el=jQuery('<div>', {
						style:'border:'+jQuery(this).prev('input').val()
					});
					jQuery('.css-border .csscolor').ColorPickerSetColor(rgb2hex(el.css('border-color')));
					//alert(jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').css('border'));
					//alert(jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').css('border'));
					jQuery('.css-border input[name="border-width"]').val(el.css('border-width'));
					if (jQuery('.css-border input[name="border-width"]').val()=='') jQuery('.css-border input[name="border-width"]').val('0px');
					jQuery('.css-border select[name="border-style"] option[value="'+el.css('border-style')+'"]').attr("selected", "selected");
				break;
				case 'background':
					jQuery('.css-background .csscolor').ColorPickerSetColor(rgb2hex(jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').css('background-color')));
					if (s = /url\("(.+)"\)/ig.exec(jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').css('background-image')) )
						jQuery('.css-background input[name="bgr-img"]').val(s[1]);
					else 
						jQuery('.css-background input[name="bgr-color-transparent"]').prop('checked', true);
					jQuery('.css-background input[name="bgr-pos"]').val(jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').css('background-position'));
					jQuery('.css-background select[name="bgr-repeat"] option[value="'+jQuery(tinymce.activeEditor.getBody()).find('.dragble .slide-inner').css('background-repeat')+'"]').attr("selected", "selected");
				break;
				
			}
		});
		jQuery('.csscolor').ColorPicker({
			flat: true,
			onChange: function (hsb, hex, rgb, el) {
				jQuery(this).parents('.csseditor').find('input.csscolor-value').val("#"+hex).prop('checked', false);
				jQuery(this).parents('.csseditor').find('input.csscolor-value').change();
			}
		});
		jQuery('.hide').live('click', function() {
			jQuery(this).parents('.csseditor').hide();
		});
	</script>
	<style>
		.csseditor {
			background:#f5f5f5;
			border:1px solid #DFDFDF;
			width:356px;
			position:absolute;
			top:0;
			right:0;
			z-index:20;
			padding:0 10px;
			display:none;
			
		}
		.padding-option {
			background:url(<?php echo get_template_directory_uri()?>/inc/images/csspadding.png)no-repeat;
			height:157px;
			width:356px;
			position:relative;
		}
		.padding-option input {
			position:absolute;
			background:none;
			border:none;
			text-align:center;
			width:67px;	
		}
		.padding-option input[name="pdtop"] {
			top:11px;
			left:138px;
		}
		.padding-option input[name="pdbottom"] {
			bottom:11px;
			left:138px;
		}
		.padding-option input[name="pdleft"] {
			left:0;
			top:68px;
		}
		.padding-option input[name="pdright"] {
			right:0;
			top:68px;
		}
		.label {
			color:#21759B;
			border-bottom:1px dashed #21759B;
			float:right;
			margin:1em 0;
			cursor:pointer;
		}
	</style>
<?php }

function lz_slides_params_update( $post_id ){  
	
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE  ) return false; 
	
    if ( !current_user_can('edit_post', $post_id) ) return false; 
	
	if (isset( $_POST['background'] ))
	update_post_meta($post_id, 'background', $_POST['background']);
	
    return $post_id;  
}


function lz_feedback_options() {
    
        add_meta_box(
            'feedback_options',
            'Feedback Options',
            'lz_feedback_options_func',
            'page'
        );
    
}
function lz_feedback_options_func ($post) {
	$options = get_post_meta($post->ID, 'feedback-options', true);
	?>
	<div class='feedback-options'>
		<h4>Options</h4>
		<p class='description'>To receive message from your visitors, specify your email for feedbacks. If option "Use department email" is enabled, your visitors will be able to choose department which should receive message. Also, if choosen department has not email, message will be sent to the email, specified in this field.</p>
		<label>Target email address</label><input type='text' name='feedback-options[email-for-feedbacks]' value='<?php echo ($options)?$options['email-for-feedbacks']:get_option('admin_email'); ?>' />&nbsp;&nbsp; or &nbsp;&nbsp;<input type='checkbox' name='feedback-options[use-department-emails]' value='1' <?php if (isset($options['use-department-emails'])&&$options['use-department-emails']) echo 'checked="checked"'; ?> /> Use department email
		
	</div>
	<div class='feedback-departments'>
	<h4>Departments</h4>
	<p style='margin-bottom:10px;' class='description'>In this section you ca specify additional contacts of your company. If your company has several departments, you can separate contacts by departments. And in this case your visitors will be able to contact appropriate department. To add new department click by button "Add new...", in the form provided, specify title and email of department. These two fields are required. You can add more contacts for department, to do this click on "Add contact...", specify in the left field of the provided line name of contact (for example Skype, ICQ, Phone, etc.), and contact in the right field (you can leave contact name empty).</p>
	<ul>
		
	</ul>
	<div class='department-details-container'>
		<?php 
			$i=0;
			if (isset($options['department'])&&is_array($options['department'])) foreach( $options['department'] as $department ) { 
			$i++;
		?>
			<div class='department-details' alt='<?php echo $i; ?>'>
				<span class='department-remove button'>Remove this department</span>
				<table>
					<tr>
						<td width='200px'>Title:</td>
						<td>
							<input type='text' name='feedback-options[department][<?php echo $i; ?>][title][value]' class='department-ttl' value='<?php echo $department['title']['value']; ?>' />
							<input type='hidden' name='feedback-options[department][<?php echo $i; ?>][title][name]' value='title' />
						</td>
					</tr>
					<tr>
						<td>Email (show on contact page <input type='checkbox' name='feedback-options[department][<?php echo $i; ?>][email][show]' value='1' <?php echo (isset($department['email']['show'])&&$department['email']['show'])?'checked="checked"':'';?> />):</td>
						<td>
							<input type='text' name='feedback-options[department][<?php echo $i; ?>][email][value]' value='<?php echo $department['email']['value']; ?>' />
							<input type='hidden' name='feedback-options[department][<?php echo $i; ?>][email][name]' value='<?php echo $department['email']['name']; ?>' />
						</td>
					</tr>
					<?php
						unset( $department['title'] );
						unset( $department['email'] );
						$x=0;
						foreach ( $department as $detail ) { $x++; ?>
						<tr>
						<td>
							<input type='text' name='feedback-options[department][<?php echo $i; ?>][<?php echo $x; ?>][name]' value='<?php echo $detail['name']; ?>' />
						</td>
						<td>
							<input type='text' name='feedback-options[department][<?php echo $i; ?>][<?php echo $x; ?>][value]' value='<?php echo $detail['value']; ?>' />
						</td>
						<td width='80px'>
							<span class='detail-remove'>Remove this</span>
						</td>
						</tr>
					<?php } ?>
					<tr>
						<td colspan='3'><div class='button more_details' style='float:right'>Add contact...</div></td>
					</tr>
				</table>
			</div>
		<?php } ?>
		
	</div>
	<script>
		if (jQuery('#page_template').val()=='feedback.php') {
				jQuery('#feedback_options').show();
				
		}
			jQuery('.department-details').each(function() {
				jQuery('.feedback-departments ul').append(jQuery('<li>').text(jQuery(this).find('.department-ttl').val()));
			});
			jQuery('.feedback-departments ul li:first').click();
			jQuery('.feedback-departments ul').append(
				jQuery('<li>', {
					'class':'newdepartment'
				}).text('Add new...')
			);
			
		</script>
	</div>
	<div class='clear'></div>
	<?php
}
function lz_feedback_options_update ( $post_id ) {
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE  ) return false; 
	
    if ( !current_user_can('edit_post', $post_id) ) return false; 
	
	if ( !isset( $_POST['feedback-options'] ) ) return false; 
	
	update_post_meta($post_id, 'feedback-options', $_POST['feedback-options']);
    
	return $post_id;
}



function themeMenu() {
	global $adminsettings, $settingOptions;
	include_once (get_template_directory()."/inc/settings.php");
	$theme = wp_get_theme( );
	add_menu_page('Theme', $theme['Name'], 'manage_options', 'LZSettings', 'thememanage', '', 64);
	add_theme_page( $theme['Name'], $theme['Name'], 'manage_options', 'LZSettings', 'thememanage');
	foreach( $adminsettings as $name=>$title ) {
		add_submenu_page( 'LZSettings', $title, $title, 'manage_options', $name, 'thememanage');
	}
	//remove_submenu_page( 'LZSettings', 'LZSettings' );
}

function thememanage() {
	global $adminsettings, $settingOptions, $settings; 
	include_once (get_template_directory()."/inc/settings.php");
	$theme = wp_get_theme( );
	
	?>
	<div id='lz-settings'>
		<div class='lz-menu'>
		<div class='lz-top'>
		<img alt="WordPress Lizard" src="<?php echo get_template_directory_uri()?>/inc/images/logo.png" class='lz-logo' />
		<div class='theme'><?php echo $theme['Name'].' '.$theme['Version']; ?></div>
		<div class='lz-links'>
			<a href="#" class="lz-support">How to start</a><br>
			<a href="http://lizardthemes.com/<?php echo strtolower( $theme['Name'] ); ?>/">Theme Homepage</a><br>
			<a href="http://lizardthemes.com/support/forum/<?php echo strtolower( $theme['Name'] ); ?>-wordpress-theme/">Support Forums</a>
		</div>
		</div>
		<div class='clear'></div>
		<div class='lz-menu-container'>
		<div class='menu-hover'></div>
		<ul>
			<?php foreach( $adminsettings as $name=>$title ) { ?>
				<li><a class='lz-menu-item <?php echo ( $_GET['page']==$name)?'active':''; ?>' alt='<?php echo $name; ?>' href='?page=<?php echo $name; ?>'><span class='icon' style="background-image:url(<?php echo get_template_directory_uri()?>/inc/images/lz_<?php echo $name; ?>_sml.png)"></span><?php echo (preg_match('/\s/', $title))?'<span class="menu-txt">'.preg_replace('/\s/', '<br />', $title).'</span>':$title; ?></a></li>
			<?php } ?>
		</ul>
		</div>
		<div class='clear'></div>
		<div class='lz-status'></div>
		<div class='lz-progress'><img src="<?php echo get_template_directory_uri()?>/inc/images/ajax-loader.gif" alt="Saving" /></div>
		<div class="button lz-savesettings"><span class='lz-led'></span>Save Changes</div>
		<a href='?page=<?php echo $_GET['page']; ?>&action=reset' class='lz-reset'>Reset <?php echo (isset($adminsettings[$_GET['page']]))?$adminsettings[$_GET['page']]:$$theme['Name']; ?> settings</a>
		<h1 class='lz-title'><?php echo (isset($adminsettings[$_GET['page']]))?$adminsettings[$_GET['page']]:$theme['Name'].' Settings'; ?></h1>
		</div>
		<div class='lz-content'>
		<a class="wp-color-result wp-picker-open" tabindex="0" style="background-color: rgb(245, 245, 245);" title="Select Color" data-current="Current Color"></a>
		<div class='lz-panel'>
			<div class='lz-support btn'>How to start?</div>
			<?php foreach( $adminsettings as $name=>$title ) { ?>
				<a href='?page=<?php echo $name; ?>' class='lz-item button-<?php echo $name; ?>' alt='<?php echo $name; ?>'>
					<img alt="<?php echo $title; ?>" src="<?php echo get_template_directory_uri()?>/inc/images/lz_<?php echo $name; ?>.png" class='normal' />
					<img alt="<?php echo $title; ?>" src="<?php echo get_template_directory_uri()?>/inc/images/lz_<?php echo $name; ?>_hover.png" class='hovered' />
					<br />
					<?php echo $title; ?>
				</a>
			<?php } ?>
			<div style='clear:both'></div>
			
		</div>
		
		<div style='clear:both'></div>
		<?php foreach( $adminsettings as $name=>$title ) { ?>
			<div class='lz-page lz-<?php echo $name; ?> <?php echo ( $_GET['page']==$name)?'active':''; ?>' alt='<?php echo $name; ?>'>
			<form action='' class='lz-form' method='POST'>
				<?php foreach( $settingOptions[$name] as $option ) { ?>
				<div class='lz-option'>
					<?php show_option($name,$option); ?>
				<div class="clear"></div></div>
				<?php } ?>
			</form>
			</div>		
		<?php } ?>
		<div class='lz-page lz-support-page'>
			<dl class='lz-support-menu'>
				<dt>Import demo content</dt>
				<dd>
					<p>To become better acquainted with the capabilities of your theme, you can install the demo content.</p>
					<p>Is important! Do not install the demo content if the site is already online and its audience already uses it.</p>
					<a href='#' class='button installdemo'>Install demo</a>
					</dd>
				<dt>Managing website elements</dt>
				<dd><p>Our framework provides easy solution for customizing your website pages. Just authorize on your website as Administrator (you already done this step, if you are reading this text), visit your site, and you will see button "Customize" in the admin bar in the top of your screen. Click by this button. As you can see all elements on your website, such as logo, menus, sidebars, etc. have three buttons on it:</p> 
				<ul>
					<li>&mdash; Red button is for removing element from your pages. ( You can restore it using item "Elements" in admin bar ).</li>
					<li>&mdash; Blue button is for getting information about this element.</li>
					<li>&mdash; Gray button is for customizing this element.</li>
				</ul>
				<p>After you did all necessary customization do not forget to click by "Save Changes" button on admin bar, which is green while customization is not saved.</p>
				</dd>
				<dt>Creating slides</dt>
				<dd>
					<p>Slideshow is a really good way to display information on your website. You can add your own slides on page <a href="edit.php?post_type=slides">Slides</a> in your dashboard. Click by link "Add New" and make a post which will be displayed as a slide. Add image to your slide, using button on the slides panel of text editor. In fact it's enough to publish your first slide. But you can also add other elements over slide image, such as text, link, image, etc. To do it click by button "Add Element" (<img src="<?php echo get_template_directory_uri(); ?>/inc/images/slidesAddElement.png" alt="Add Element" />) on the slides panel of text editor. You will see new element "Type your text here or put an image. To start or stop dragging this element over the slide, use doubleclick" on your slide, you can click on it twice and drag it to any place of the slide. Do not forget to save changes in the post to view result on your site.</p>
				</dd>
				<dt>Using showroom</dt>
				<dd>
					<p>Showroom box is a tool for displaying appropriate pages of your website on the main page. It might be pages, posts or custom records, such as e-shop items or portfolios. There are two ways for managing showroom on your website:
					<ul>
						<li>&mdash; you can select Showroom source on page General of the theme settings and disable option "Show only records marked for Showroom". In this case your last records will be displayed.</li>
						<li>&mdash; or you can turn on option "Show only records marked for Showroom", and select needed records manually, by turning on option "Show this record in the showroom" on add/edit page.</li>
					</ul>
					</p>
				</dd>
				<dt>Creating contact form</dt>
				<dd>
					<p>Contact form on your website is the best way to receive feedback from your visitors. To create your own contact form just create a new page and select "Contact Form" for page template. After you did it you will be able to configure your contact form by managing options in box Feedback Options. You can find additional instructions there.</p>
				</dd>
			</dl>
		</div>
		<div class='lz-contacts'>
			Theme Author:   <a href="http://lizardthemes.com">LizardThemes</a><br>
		</div>
		</div>
	</div>
	<div class="clear"></div>
	<?php
	
}
function show_option($section, $option) {
	global $settings;
	
	
	

	switch( $option['type'] ) {
		
		case 'text': ?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description"><?php echo $option['description']; ?></p>
				<input autocomplete="off" type="text" name="<?php echo $option['name']; ?>" value="<?php if (isset($settings[$section][$option['name']])) echo htmlspecialchars( $settings[$section][$option['name']] ); ?>" />
		<?php break;
		
		case 'image': ?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description">
				
				<?php echo $option['description']; ?></p>
				<input type="text" name="<?php echo $option['name']; ?>" value="<?php echo $settings[$section][$option['name']]; ?>" /><span class="lz-imageupload button">Upload</span>
				<span class="img"><img alt="WordPress Lizard" src="<?php echo $settings[$section][$option['name']]; ?>" /></span>
				<div class="clear"></div>
				
				
		<?php break;
		
		case 'list': ?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description"><?php echo $option['description']; ?></p>
				<select name="<?php echo $option['name']; ?>">
					<?php foreach( $option['values'] as $val=>$ttl ) { 
					if ( $val == $settings[$section][$option['name']] ) { $selected=' selected="selected"'; } else $selected='';?>
						<option value="<?php echo $val; ?>"<?php echo $selected; ?>><?php echo $ttl; ?></option>
					<?php } ?>
				</select>
				<div class="clear"></div>
				
		<?php break;
		
		case 'select': ?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description"><?php echo $option['description']; ?></p>
				<div class='lz-select'><input type="hidden" name="<?php echo $option['name']; ?>" value="<?php echo $settings[$section][$option['name']]; ?>">
					<?php foreach( $option['values'] as $val=>$src ) { 
					if ( $val == $settings[$section][$option['name']] ) { $selected=' active'; } else $selected='';?>
						<img src="<?php echo get_template_directory_uri()?>/inc/images/<?php echo $src; ?>" class="<?php echo $selected; ?>" alt="<?php echo $val; ?>" />
					<?php } ?>
				</div>
				<div class="clear"></div>
				
		<?php break;
		
		case 'social': 
			$settings[$option['values']]=lz_loadsettings( $option['values'] );?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description"><?php echo $option['description']; ?></p>
				<div class='lz-multiselect'>
					<?php foreach( $settings[$option['values']] as $val=>$code ) { 
					if ( in_array($val, $settings[$section][$option['name']]) ) {$selected=' checked="checked"';} else $selected=''; ?>
					<div class='lz-check<?php if (in_array($val, $settings[$section][$option['name']])) echo ' checked'; ?> label'>
						<input type='hidden' <?php if (in_array($val, $settings[$section][$option['name']])) echo 'value="'.$val.'"'; else echo 'alt="'.$val.'"'; ?>  name='<?php echo $option['name']; ?>[]' />
						<?php echo $code['title'];?>
					</div>
						
					<?php } ?>
				</div>
				<div class="clear"></div>
				
		<?php break;
		
		case 'logic': ?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description"><?php echo $option['description']; ?></p>
				<div class='lz-check<?php if ($settings[$section][$option['name']]) echo ' checked'; ?>'>
					<input type='hidden' <?php if ($settings[$section][$option['name']]) echo 'value="1"'; else echo 'alt="1"'; ?>  name='<?php echo $option['name']; ?>' />
				</div>
		<?php break;
		
		case 'textarea': ?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description"><?php echo $option['description']; ?></p>
				<textarea rows="5" autocomplete="off" name="<?php echo $option['name']; ?>"><?php echo htmlspecialchars( $settings[$section][$option['name']] ); ?></textarea>
		<?php break;
		
		case 'systeminfo': ?>
				<h3><?php echo $option['caption']; ?></h3>
				<p class="description"><?php echo $option['description']; ?></p>
				<input autocomplete="off" type="checkbox" name="allowdetails" value="1" checked="checked" id="allowdetails" /><label for="allowdetails">Attach system details to the message</label><br />
				<textarea rows="15" autocomplete="off" name="<?php echo $option['name']; ?>">Type your message here...
				</textarea>
				<div id='details' style='display:none'>
***
<?php echo $_SERVER['SERVER_NAME']."\r\n"; ?>
<?php echo $_SERVER['SERVER_SOFTWARE']."\r\n"; ?>
<?php echo 'PHP '.phpversion()."\r\n"; ?>
<?php echo $_SERVER["HTTP_USER_AGENT"]."\r\n"; ?>
				</div>
				<script>
					jQuery('input[name="allowdetails"]').live('change', function() {
						if( jQuery(this).is(':checked') ) {
							jQuery('textarea[name="<?php echo $option['name']; ?>"]').val(jQuery('textarea[name="<?php echo $option['name']; ?>"]').val()+jQuery('#details').html());
						} else {
							var message=jQuery('textarea[name="<?php echo $option['name']; ?>"]').val();
							message=message.split('***');
							jQuery('textarea[name="<?php echo $option['name']; ?>"]').val(message[0]);
						}
					});
					jQuery('textarea[name="<?php echo $option['name']; ?>"]').html(jQuery('textarea[name="<?php echo $option['name']; ?>"]').html()+jQuery('#details').html());
				</script>
		<?php break;
		
		case 'submit' : ?>
			<input type="submit" class="button" name="<?php echo $option['name']; ?>" value="<?php echo $option['caption']; ?>" />
			<script>
				jQuery('input[name="<?php echo $option['name']; ?>"]').live('click', function() {
					var data=jQuery('.lz-page.active .lz-form').serialize();
					jQuery('.lz-progress').show();
					jQuery.post('<?php echo admin_url( 'admin-ajax.php' ); ?>', {
							'action':'lz_sendmail',
							'section':jQuery('.lz-page.active').attr('alt'),
							'data':data
						}, 
						function(response){ 
							jQuery('.lz-status').text(response).show();
							jQuery('.lz-progress').hide();
							setTimeout("jQuery('.lz-status').hide()", 2000);
							setTimeout("jQuery('.lz-status').text('');", 2000);
						}
					);
					return false;
				});
			</script>
		<?php break;
		
		case 'paragraph': ?>
			<p><?php echo $option['description']; ?></p>
		<?php break;
		
		case 'frame': 
			$theme = wp_get_theme( );
			?>
			<h3><?php echo $option['caption']; ?></h3>
			<iframe style="width:100%;height:500px" src="http://lizardthemes.com/latest/?except=<?php echo $theme['Name']; ?>"></iframe>
		<?php break;
		
	}
}