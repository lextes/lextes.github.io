<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js?ver=3.4.1"></script>  
<script type="text/javascript" src="/wp-includes/js/tinymce/tiny_mce_popup.js"></script>
<link href='<?php echo $_GET['url'];?>/../styles/shortcodes.css' rel='stylesheet' type='text/css'>
<?php

switch ( $_GET['button'] ) {
	case 'columns':
		columnshortcode();
		break;
	case 'buttons':
		buttonshortcode();
		break;
	case 'highlights':
		highlightsshortcode();
		break;
}

function highlightsshortcode() { ?>
	<script>
		jQuery('.input').live('click', function() {
			var shortcode_value = 's';
			var shortcode='<div class="highlight '+jQuery(this).attr('alt')+'"><div class="inner"><p><?php echo ($_GET['txt'])?$_GET['txt']:'Text'?></p></div></div>';
			tinyMCEPopup.editor.execCommand('mceInsertContent', false, shortcode ) ;
			tinyMCEPopup.close();
		});
	</script>
	<style>
		table {
			width:100%;
		}
		table td{
			text-align:center;
		}
		table tr {
			height:40px;
		}
		.input {
			display:block;
			width:64px;
			height:64px;
			cursor:pointer;
		}
		.input.red {
			background:url(<?php echo $_GET['url'];?>/../images/lz/highlight-red.png) left top no-repeat;
		}
		.input.green {
			background:url(<?php echo $_GET['url'];?>/../images/lz/highlight-green.png) left top no-repeat;
		}
		.input.yellow {
			background:url(<?php echo $_GET['url'];?>/../images/lz/highlight-yellow.png) left top no-repeat;
		}
		.input.blue {
			background:url(<?php echo $_GET['url'];?>/../images/lz/highlight-blue.png) left top no-repeat;
		}
	</style>
	<table><tr>
	<td><span class='input red' alt='red'></span></td>
	<td><span class='input green' alt='green'></span></td>
	<td><span class='input yellow' alt='yellow'></span></td>
	<td><span class='input blue' alt='blue'></span></td>
	</tr></table>
<?php }

function buttonshortcode() { ?>
<script>
	jQuery('.btn').live('click', function() {
		var s=prompt("Button", "Link:");
	    tinyMCEPopup.editor.execCommand('mceInsertContent', false, '<a class=\''+jQuery(this).attr('class')+'\' href=\''+s+'\'>text</a>' ) ;
	    tinyMCEPopup.close();
	});
</script>
<style>
	table {
		width:100%;
	}
	table td{
		text-align:center;
	}
	table tr {
		height:40px;
	}
</style>
<table>
<tr>
	<td><a class='btn orange small'>text</a></td>
	<td><a class='btn green small'>text</a></td>
	<td><a class='btn blue small'>text</a></td>
	<td><a class='btn white small'>text</a></td>
	<td><a class='btn black small'>text</a></td>
</tr>
<tr>
	<td><a class='btn orange medium'>text</a></td>
	<td><a class='btn green medium'>text</a></td>
	<td><a class='btn blue medium'>text</a></td>
	<td><a class='btn white medium'>text</a></td>
	<td><a class='btn black medium'>text</a></td>
</tr>
<tr>
	<td><a class='btn orange big'>text</a></td>
	<td><a class='btn green big'>text</a></td>
	<td><a class='btn blue big'>text</a></td>
	<td><a class='btn white big'>text</a></td>
	<td><a class='btn black big'>text</a></td>
</tr>
</table>

<?php }

function columnshortcode() { ?>
	<script>
	jQuery('.cols').live('click', function() {
		
		var shortcode_value = 's';
		var shortcode='';
		switch(jQuery(this).attr('alt')) {
			case '2':
				shortcode='<div class="cols two-equal"><div class="column">Column #1</div><div class="column last">Column #2</div></div>'+"\r\n&nbsp;";
				break;
			case '3':
				shortcode='<div class="cols three"><div class="column">Column #1</div><div class="column">Column #2</div><div class="column last">Column #3</div></div>'+"\r\n&nbsp;";
				break;
			case 'propleft':
				shortcode='<div class="cols two-right"><div class="column">Column #1</div><div class="column last">Column #2</div></div>'+"\r\n&nbsp;";
				break;
			case 'propright':
				shortcode='<div class="cols two-left"><div class="column">Column #1</div><div class="column last">Column #2</div></div>'+"\r\n&nbsp;";
				break;
		}
		
		tinyMCEPopup.editor.execCommand('mceInsertContent', false, shortcode ) ;
	    tinyMCEPopup.close();
	});
</script>
<style>
	table {
		width:100%;
	}
	table td{
		text-align:center;
	}
	table tr {
		height:40px;
	}
	.cols {
		width:113px;
		height:101px;
		cursor:pointer;
		display:block;
	}
	.cols2 {
		background:url(<?php echo $_GET['url'];?>/../inc/images/cols2.png) left top no-repeat;
	}
	.cols3 {
		background:url(<?php echo $_GET['url'];?>/../inc/images/cols3.png) left top no-repeat;
	}
	.cols4 {
		background:url(<?php echo $_GET['url'];?>/../inc/images/cols4.png) left top no-repeat;
	}
	.colsprop {
		background:url(<?php echo $_GET['url'];?>/../inc/images/colsprop.png) left top no-repeat;
	}
</style>
<table><tr>
<td><span class='cols cols2' alt='2'></span></td>
<td><span class='cols cols3' alt='3'></span></td>
<td><span class='cols cols4' alt='propleft'></span></td>
<td><span class='cols colsprop' alt='propright'></span></td>
</tr></table>
<?php }