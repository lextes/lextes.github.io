<?php
$lz_default['general']=array(
	'site_title'=>'%1$s %2$s',
	'logo'=>get_template_directory_uri().'/images/logo.png',
	'favicon'=>get_template_directory_uri().'/images/lz/favicon.png',
	'footer_txt'=>'&copy; '.get_bloginfo('name')
);
$lz_default['slider']=array(
	'innerpages'=>true,
	'speed'=>'2000',
	'delay'=>'5000',
	'effect'=>'lizard'
);
$lz_default['showroom']=array(
	'showroomsrc'=>'page',
	'onlymarked'=>true,
	'srreadmore'=>'Read more',
	'srinnerpages'=>false,
	'length'=>100
);
$lz_default['layout']=array(
	'pagination'=>'dynamic',
	'postmeta'=>'By %3$s in %2$s, Releases with %4$s',
	'fimage_width'=>225,
	'fimage_height'=>150,
	'cutcontent'=>true,
	'contentlength'=>800,
	'fimage_position'=>'alignleft',
	'relatedposts'=>true
);
$lz_default['socialbuttons']=array(
	'buttons'=>array( 'facebooklike', 'twitter' ),
);
$lz_default['seo']=array(
	'description'=>'',
	'keywords'=>'',
	'categoryindex'=>false,
	'tagindex'=>false,
	'archiveindex'=>false,
	'authorindex'=>false,
	'searchindex'=>false,
);
$lz_default['menus']=array(
	'effect'=>'slidedown',
	'speed'=>'500',
	'delay'=>'800',
	'showarrows'=>true
);
$lz_default['integration']=array(
	'css'=>'',
	'headcode'=>''
);
$lz_default['elements']=array(
	'logo'=>array('title'=>'Logo', 'show'=>true, 'help'=>'logo', 'edit'=>'admin.php?page=general'),
	'search'=>array('title'=>'Search', 'show'=>true, 'help'=>'search', 'edit'=>'widgets.php'),
	'secondary-menu'=>array('title'=>'Secondary Menu', 'show'=>true, 'help'=>'menus', 'edit'=>'nav-menus.php'),
	'main-menu'=>array('title'=>'Main Menu', 'show'=>true, 'help'=>'menus', 'edit'=>'nav-menus.php'),
	'slider'=>array('title'=>'Slider', 'show'=>true, 'help'=>'slider', 'edit'=>'admin.php?page=slider'),
	'showroom'=>array('title'=>'Showroom', 'show'=>true, 'help'=>'showroom', 'edit'=>'admin.php?page=showroom'),
	'leftsidebar'=>array('title'=>'Left Sidebar', 'show'=>false, 'help'=>'sidebar', 'edit'=>'widgets.php'),
	'rightsidebar'=>array('title'=>'Right Sidebar', 'show'=>true, 'help'=>'sidebar', 'edit'=>'widgets.php'),
	'social'=>array('title'=>'Social', 'show'=>true, 'help'=>'social', 'edit'=>'admin.php?page=socialbuttons'),
	'footer'=>array('title'=>'Footer', 'show'=>true, 'help'=>'footer', 'edit'=>'widgets.php')
);
$lz_default['fonts']=array(
	'heading'=>'Open Sans',
	'body'=>'Open Sans',
	'menu'=>'Open Sans'
);

$lz_default['buttonspresets']=array(
				'facebooklike' => array (
					'title'=>'Facebook Like',
					'code'=>'<iframe src="//www.facebook.com/plugins/like.php?href=lz_social_url&amp;send=false&amp;layout=box_count&amp;width=50&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=65&amp;locale=en_US" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:65px;" allowTransparency="true"></iframe>'
				),
				'twitter' => array (
					'title'=>'Twitter',
					'code'=>'<a href="https://twitter.com/share" class="twitter-share-button" data-count="vertical" data-lang="en">Tweet</a>
			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>'
				),
				'gglplus' => array (
					'title'=>'Google +1',
					'code'=>'<g:plusone size="tall"></g:plusone>
			<script type="text/javascript">
			  (function() {
				var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
				po.src = "https://apis.google.com/js/plusone.js";
				var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
			  })();
			</script>'
				),
				'linkedin' => array (
					'title'=>'Linked In',
					'code'=>'<script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
			<script type="IN/Share" data-counter="top"></script>'
				),
				'reddit' => array (
					'title'=>'Reddit',
					'code'=>'<script type="text/javascript" src="http://www.reddit.com/static/button/button2.js"></script>'
				),
				'pinterest' => array (
					'title'=>'Pinterest',
					'code'=>'<a href="http://pinterest.com/pin/create/button/?url=lz_social_url&media=lz_social_img_url&description=lz_social_title" class="pin-it-button" count-layout="vertical"><img border="0" src="//assets.pinterest.com/images/PinExt.png" title="Pin It" /></a><script type="text/javascript" src="//assets.pinterest.com/js/pinit.js"></script>'
				),
				'buffer' => array (
					'title'=>'Buffer',
					'code'=>'<a href="http://bufferapp.com/add" class="buffer-add-button" data-count="vertical">Buffer</a><script type="text/javascript" src="http://static.bufferapp.com/js/button.js"></script>'
				),
				'stumbleupon' => array (
					'title'=>'Stumbleupon',
					'code'=>'<su:badge layout="5"></su:badge>
			 <script type="text/javascript"> 
			 (function() { 
				 var li = document.createElement("script"); li.type = "text/javascript"; li.async = true; 
				 li.src = window.location.protocol + "//platform.stumbleupon.com/1/widgets.js"; 	
				 var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(li, s); 
			 })(); 
			 </script>'
				),
				'dzone' => array (
					'title'=>'DZone',
					'code'=>'<script type="text/javascript">var dzone_url = "[lz_social_url]";</script>
			<script type="text/javascript">var dzone_title = "[lz_social_title]";</script>
			<script type="text/javascript">var dzone_blurb = "[lz_social_title]";</script>
			<script type="text/javascript">var dzone_style = "1";</script>
			<script language="javascript" src="http://widgets.dzone.com/links/widgets/zoneit.js"></script>'
				),
				'flattr' => array (
					'title'=>'Flattr',
					'code'=>'<script type="text/javascript">
(function() {
    var s = document.createElement("script");
    var t = document.getElementsByTagName("script")[0];

    s.type = "text/javascript";
    s.async = true;
    s.src = "http://api.flattr.com/js/0.6/load.js?mode=auto";

    t.parentNode.insertBefore(s, t);
 })();
    window.onload = function() {
        FlattrLoader.render({
            "uid": "flattr",
            "url": "lz_social_url",
            "title": "lz_social_title",
            "description": "lz_social_desc"
        }, "flattrBtn", "replace");
    }
</script>
<div id="flattrBtn"></div>'
				),
				'tumblr' => array (
					'title'=>'Tumblr',
					'code'=>'<a href="http://www.tumblr.com/share" title="Share on Tumblr" style="display:inline-block; text-indent:-9999px; overflow:hidden; width:61px; height:20px; background:url(http://platform.tumblr.com/v1/share_2.png) top left no-repeat transparent;">Share on Tumblr</a>'
				),
				'googleshare' => array (
					'title'=>'Google Share',
					'code'=>'<div class="g-plus" data-action="share" data-annotation="vertical-bubble" data-height="60"></div>
							<script type="text/javascript">
							window.___gcfg = {lang: "en-GB", parsetags: "onload"};
							(function() {
								var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
								po.src = "https://apis.google.com/js/plusone.js";
								var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
							  })();
							</script>'
				),
				
);