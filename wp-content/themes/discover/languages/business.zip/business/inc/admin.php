<?php
	
if ( !is_user_logged_in() ) return;
function is_dash() {
	 return in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ) )||is_admin();
}

if ( current_user_can('administrator') ) {
	if ( is_dash() ) {
		include_once ( get_template_directory().'/inc/dashboard.php' );
	} else {
		include_once ( get_template_directory().'/inc/frontend.php' );
	}
}

if ( current_user_can('edit_posts') ) {
	//echo '123';
	include_once ( get_template_directory().'/inc/author.php' );
} //else echo '321';

add_action('wp_ajax_save_customize', 'save_customize');
function save_customize() {
	global $settings;
	foreach( $_POST['data'] as $key=>$value ){
		$settings['elements'][$key]['show']=($value=='block');
	}
	update_option( 'elements', $settings['elements'] );
	
	die();
}

add_action('wp_ajax_save_fonts', 'save_fonts');
function save_fonts() {
	global $settings;
	foreach( $_POST['data'] as $key=>$value ){
		$settings['fonts'][$key] = $value;
	}
	update_option( 'fonts', $settings['fonts'] );
	
	
	die();
}



add_action('wp_ajax_save_settings', 'save_settings');
function save_settings() {
	
	parse_str($_POST['data'], $values);
	$values=removeslashes( $values );
	update_option( $_POST['section'], $values );
	echo "New configuration saved.";
	die();
}



add_action('wp_ajax_lz_sendmail', 'lz_sendmail');
function lz_sendmail() {
	
	parse_str($_POST['data'], $values);
	$values=removeslashes( $values );
	$message='';
	foreach( $values as $name=>$value ){
		$message.="\r\n".$name.':'.$value;
	}
	mail('support@lizardthemes.com', 'Topic', $message);
	echo "Your message was sent to support.";
	die();
}



add_action('wp_ajax_upload_image', 'upload_image');
function upload_image() {
	
	$file=$_FILES['uploadfile'];
	$overrides['test_form']=false;
	$file=wp_handle_upload( $file, $overrides );
	echo $file['url'];
	
	die();
	
}

add_action('wp_ajax_install_demo', 'install_demo');
function install_demo() {
	include_once ( get_template_directory().'/inc/demo.php' );	
	echo 'Demo content installed';
	die();
	
}

function removeslashes($var) {
	if (is_array($var)) foreach ($var as $key=>$value) {
		$var[$key]=removeslashes($value);
	} else {
		return stripslashes($var);
	}
	return $var;
}

