<?php

if ( !is_super_admin() ) return;

require_once(ABSPATH . 'wp-admin/includes/image.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');


$items=array(
	'4' => 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.', 
	'3' => 'Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. ', 
	'2' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua', 
	'1' => 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.' 
);
foreach ($items as $id=>$title) {
	$post = array(
	  'post_author'    => get_current_user_id(),
	  'post_content'   => 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia',
	  'post_status'    => 'publish',
	  'post_title'     => 'Item #'.$id,
	  'post_type'      => 'page',
	);  
	$page=wp_insert_post($post);
	add_post_meta($page, 'forshowroom', '1');
	$file = wp_upload_bits('item4img.jpg', null, file_get_contents(get_template_directory().'/images/demo/item'.$id.'.jpg'));
	$wp_filetype = wp_check_filetype($file['file'], null);
	$attachment = array(
		'post_mime_type' => $wp_filetype['type'],
		'post_title' => 'item'.$id.'-img',
		'post_content' => '',
		'post_status' => 'inherit'
	);
	$attach_id = wp_insert_attachment( $attachment, $file['file'], $page );
	$attach_data = wp_generate_attachment_metadata( $attach_id, $file['file'] );
	wp_update_attachment_metadata( $attach_id, $attach_data );
	add_post_meta($page, '_thumbnail_id', $attach_id);
}

$post = array(
	  'post_author'    => get_current_user_id(),
	  'post_content'   => '[map address="22b baker street london" type="hybrid" zoom="16" /]',
	  'post_status'    => 'publish',
	  'post_title'     => 'Contact Us',
	  'post_type'      => 'page'
	);
	
$page=wp_insert_post($post);
add_post_meta($page, '_wp_page_template', 'feedback.php');
$feedback=Array(
    'email-for-feedbacks' => get_option('admin_email'),
    'use-department-emails' => true,
    'department' => Array (
		'1' => Array(
			'title' => Array ( 'value' => 'Main office', 'name' => 'title' ),
			'email' => Array ( 'value' => get_option('admin_email'), 'name' => 'Email' ),
			'3' => Array('name' => '', 'value' => 'London, Baker st, 22b.'),
			'4' => Array('name' => 'Phone:', 'value' => '555-16-01'),
			'5' => Array('name' => 'Fax:', 'value' => '555-16-01'),
		),
		'2' => Array(
			'title' => Array ( 'value' => 'Branch office', 'name' => 'title' ),
			'email' => Array ( 'value' => get_option('admin_email'), 'name' => 'Email' ),
			'3' => Array('name' => '', 'value' => 'London, Baker st, 25b.'),
			'4' => Array('name' => 'Phone:', 'value' => '555-16-02'),
		)
	)
);
add_post_meta($page, 'feedback-options', $feedback);