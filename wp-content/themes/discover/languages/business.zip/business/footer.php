<?php global $settings; ?><div class="clear"></div>
</div>

<?php if ( $settings['elements']['social']['show'] || is_super_admin() ) { ?>
<div id="social-buttons" class="lzblock" data-block="social"><ul>
	<?php
		$settings['buttonspresets']=lz_loadsettings( 'buttonspresets' );
		foreach( $settings['socialbuttons']['buttons'] as $button ) {
			if ($button=='') continue;
			$code=$settings['buttonspresets'][$button]['code'];
			$href=get_bloginfo('url').$_SERVER['REQUEST_URI'];
			$ttl=sprintf($settings['general']['site_title'],wp_title( '|', false, 'right' ),get_bloginfo('name'));
			if (is_single()) {$img=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'medium');$img=$img[0];} else 
			{ $img=$settings['general']['logo']; }
			$code=preg_replace('/lz_social_url/', $href, $code);
			$code=preg_replace('/lz_social_title/', $ttl, $code);
			$code=preg_replace('/lz_social_desc/', $ttl, $code);
			$code=preg_replace('/lz_social_img_url/', $img, $code);
			echo '<li>'.$code.'</li>';
		}
	?>
	<li><span id='social-buttons-close'><?php echo __('Hide', 'lizard'); ?></span></li>
</ul>
<script>
	jQuery('#social-buttons-close').live('click', function(){jQuery('#social-buttons').hide();});
	jQuery(document).ready(function() {
		jQuery('#social-buttons').css('top', (jQuery(window).height()-jQuery('#social-buttons').height())/2);
		<?php if ( $settings['elements']['social']['show'] ) echo 'jQuery("#social-buttons").show()'; ?>
		
	});
</script>
</div>
<?php } ?>
<div id="footer">
	<div class="container">
	<?php if ( $settings['elements']['footer']['show'] || is_super_admin() ) { ?>
	<div class="lzblock" data-block="footer">
		<div class="widgets">
			<div class="widgets-block">
				<?php dynamic_sidebar( 'Footer left' ); ?>
			</div>
			<div class="widgets-block">
				<?php dynamic_sidebar( 'Footer middle' ); ?>
			</div>
			<div class="widgets-block">
				<?php dynamic_sidebar( 'Footer right' ); ?>
			</div>
			<div class="clear"></div>
		</div>
		</div>
		<?php } ?>
	</div>		
		<div class="copyright">
		<div class="container">
			<p><?php echo $settings['general']['footer_txt']; ?></p>
		</div>
		</div>
	</div>
	<?php wp_footer(); ?>
</div></body>
</html>