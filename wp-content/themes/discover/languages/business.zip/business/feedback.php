<?php
	/*Template Name: Contact form*/
?>
<?php get_header(); ?>

<div id='container'>
<?php if ( have_posts() ) : ?>
	<?php while ( have_posts() ) : the_post(); ?>
	<div id="post-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
		<h1 class="post-title"><?php the_title(); ?></h1>

		<?php
			$feedback = get_post_meta($post->ID, 'feedback-options', true);
			if ( isset($_POST[$_SESSION['nospam']])&&$_POST[$_SESSION['nospam']]!='' ) {
				$msg='';
				$msg.='Name:'.$_POST['uName']."\r\n";
				$msg.='To Department:'.$_POST['uDepartment']."\r\n\r\n";
				$msg.=$_POST[$_SESSION['nospam']];
				
				foreach( $feedback['department'] as $department ) {
					if ( $department['title']['value']!=$_POST['uDepartment'] ) continue;
					$email=$department['email']['value'];
				}
				
				if (!isset($email)||$email=='')
					$email=$feedback['email-for-feedbacks'];
				
				if (wp_mail( $email, $_POST['uSubject'], $msg, "From: ".$_POST['uEmail'] )) {
					echo '<p class="feedback-msg">'.__('Your message has been sent successfully.', 'lizard').'</p>';
				} else {
					echo '<p class="feedback-msg">'.__('Message was not sent.', 'lizard').'</p>';
				}
				
			}
		?>

		<div class="post-body">
		<?php the_post_thumbnail('post-thumbnail', array('class'=>$settings['layout']['fimage_position'])); ?>
			<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>' ) ); ?>
			<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:' ), 'after' => '</div>' ) ); ?>
			<div class="clear" style='height:40px;'></div>
			
			<?php
				if (is_array($feedback['department'])) { ?>
				<div class='departments'>
					<?php foreach( $feedback['department'] as $department ) { ?>
						<div class='department'>
							<h4><?php echo $department['title']['value']; ?></h4>
							<?php 
								foreach( $department as $key=>$detail ) { if ($key=='title'||$key=='email') continue;?>
									<p><span><?php echo $detail['name']; ?></span> <?php echo $detail['value']; ?></p>
								<?php } ?>
							<?php if ($department['email']['show']) { ?><p><span><?php _e('E-mail', 'lizard'); ?>:</span> <?php echo $department['email']['value']; ?></p><?php } ?>
						</div>
					<?php } ?>
				</div>
				<?php } ?>
			
			<div class='contactform'>
			<form action='' method='POST'>
				<div class='uDetail'><span><?php _e('Name', 'lizard'); ?>:</span><div class='input'><input type='text' name='uName' value='' /></div></div>
				<div class='uDetail'><span><?php _e('Email', 'lizard'); ?>:</span><div class='input'><input type='text' name='uEmail' value='' /></div></div>
				<div class='uDetail'><span><?php _e('Subject', 'lizard'); ?>:</span><div class='input'><input type='text' name='uSubject' value='' /></div></div>
				<?php if ( count($feedback['department']) > 1 ) { ?>
				<div class='uDetail'><span><?php _e('Department', 'lizard'); ?>:</span><div class='input'><select name='uDepartment'>
					<?php foreach( $feedback['department'] as $department ) { ?>
						<option value="<?php echo $department['title']['value']; ?>"><?php echo $department['title']['value']; ?></option>
					<?php } ?>
				</select></div></div>
				<?php } ?>
				<div class='uDetail'><span><?php _e('Message', 'lizard'); ?>:</span><div class='input'><textarea name='uMessage' rows='8'></textarea></div></div>
				<input type='submit' value='Send' />
				<div class="clear"></div>
			</form>
			</div>
			
			
		</div>
		</div>
	<?php endwhile; ?>
<?php endif; // end have_posts() check ?>
</div>
<script>
	jQuery('textarea[name="uMessage"]').attr('name', '<?php echo $_SESSION['nospam']; ?>');
</script>

<?php get_sidebar(); ?>

<?php get_footer(); ?>